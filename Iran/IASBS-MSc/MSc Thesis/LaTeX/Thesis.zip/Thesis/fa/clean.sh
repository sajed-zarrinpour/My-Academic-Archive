rm -f *.aux *.log *.lof *.out *.toc *.lot *.idx *.xdy *.glo 

